package com.bassboost.tv

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {

    companion object { const val PREFS = "bass_prefs" }

    private lateinit var prefs: SharedPreferences
    private lateinit var statusView: TextView
    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "status") runOnUiThread { refreshStatus() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(60), dp(40), dp(60), dp(40))
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(text("BASS BOOST TV  -  ALWAYS ON", 30f, Color.WHITE))

        addSlider(root, "Bass strength", "bass", 800, 1000)
        addSlider(root, "Low-frequency EQ boost (%)", "eq", 70, 100)
        addSlider(root, "Loudness gain (mB, 100 = +1 dB)", "gain", 300, 1500)

        statusView = text("", 16f, Color.LTGRAY)
        root.addView(statusView, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(20) })
        root.addView(text("Use LEFT / RIGHT on the remote to change sliders.", 14f, Color.GRAY))
        setContentView(root)

        startBass()   // starts automatically every time the app opens
    }

    private fun addSlider(parent: LinearLayout, label: String, key: String, def: Int, max: Int) {
        val title = text("$label: ${prefs.getInt(key, def)}", 18f, Color.WHITE)
        parent.addView(title, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(20) })
        val sb = SeekBar(this).apply {
            this.max = max
            progress = prefs.getInt(key, def)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    title.text = "$label: $p"
                    prefs.edit().putInt(key, p).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { startBass() }
            })
        }
        parent.addView(sb, LinearLayout.LayoutParams(-1, -2))
        if (key == "bass") sb.requestFocus()
    }

    private fun text(t: String, size: Float, color: Int) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun refreshStatus() {
        statusView.text = prefs.getString("status", "Starting...")
    }

    private fun startBass() {
        val i = Intent(this, BassService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }

    override fun onResume() {
        super.onResume()
        prefs.registerOnSharedPreferenceChangeListener(listener)
        refreshStatus()
    }

    override fun onPause() {
        prefs.unregisterOnSharedPreferenceChangeListener(listener)
        super.onPause()
    }
}
