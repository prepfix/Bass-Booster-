package com.bassboost.tv

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.media.audiofx.AudioEffect
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

/** One set of effects attached to one audio session (0 = global output mix). */
class Chain(private val session: Int) {
    private var bass: BassBoost? = null
    private var eq: Equalizer? = null
    private var loud: LoudnessEnhancer? = null
    private val prio = 100

    val bassOk get() = bass != null
    val eqOk get() = eq != null
    val loudOk get() = loud != null

    fun apply(p: SharedPreferences) {
        val bs = p.getInt("bass", 500)
        val eqPct = p.getInt("eq", 30)
        val gain = p.getInt("gain", 0)
        val treb = p.getInt("treb", 30)

        try {
            if (bass == null || bass?.hasControl() == false) {
                try { bass?.release() } catch (_: Exception) {}
                bass = BassBoost(prio, session)
            }
            bass?.let {
                if (it.strengthSupported) it.setStrength(bs.toShort())
                it.enabled = true
            }
        } catch (e: Exception) {
            try { bass?.release() } catch (_: Exception) {}
            bass = null
        }

        try {
            if (eq == null || eq?.hasControl() == false) {
                try { eq?.release() } catch (_: Exception) {}
                eq = Equalizer(prio, session)
            }
            eq?.let { e ->
                val max = e.bandLevelRange[1].toInt()
                for (b in 0 until e.numberOfBands) {
                    val hz = e.getCenterFreq(b.toShort()) / 1000
                    val level = when {
                        hz <= 120 -> max * eqPct / 100      // deep bass only
                        hz >= 1000 -> max * treb / 100      // mids/highs lift
                        else -> 0                            // keep low-mids flat (no mud)
                    }
                    e.setBandLevel(b.toShort(), level.toShort())
                }
                e.enabled = true
            }
        } catch (e: Exception) {
            try { eq?.release() } catch (_: Exception) {}
            eq = null
        }

        try {
            if (loud == null || loud?.hasControl() == false) {
                try { loud?.release() } catch (_: Exception) {}
                loud = LoudnessEnhancer(session)
            }
            loud?.let {
                it.setTargetGain(gain)
                it.enabled = true
            }
        } catch (e: Exception) {
            try { loud?.release() } catch (_: Exception) {}
            loud = null
        }
    }

    fun release() {
        try { bass?.release() } catch (_: Exception) {}
        try { eq?.release() } catch (_: Exception) {}
        try { loud?.release() } catch (_: Exception) {}
        bass = null; eq = null; loud = null
    }
}

class BassService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private val global = Chain(0)
    private val sessions = HashMap<Int, Chain>()
    private lateinit var prefs: SharedPreferences

    // Re-checks every 15 s so effects come back if the system or another app drops them.
    private val watchdog = object : Runnable {
        override fun run() {
            applyAll()
            handler.postDelayed(this, 15000)
        }
    }

    private val sessionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val id = intent.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, -1)
            val pkg = intent.getStringExtra(AudioEffect.EXTRA_PACKAGE_NAME)
            if (id <= 0 || pkg == packageName) return
            when (intent.action) {
                AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION -> {
                    if (!sessions.containsKey(id)) sessions[id] = Chain(id)
                    sessions[id]?.apply(prefs)
                    writeStatus()
                }
                AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION -> {
                    sessions.remove(id)?.release()
                    writeStatus()
                }
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
        val f = IntentFilter().apply {
            addAction(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION)
            addAction(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(sessionReceiver, f, Context.RECEIVER_EXPORTED)
        else registerReceiver(sessionReceiver, f)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        handler.removeCallbacks(watchdog)
        handler.post(watchdog)
        return START_STICKY
    }

    private fun applyAll() {
        global.apply(prefs)
        for (c in sessions.values) c.apply(prefs)
        writeStatus()
    }

    private fun writeStatus() {
        fun s(ok: Boolean) = if (ok) "OK" else "not supported"
        val txt = "ALWAYS ON\n" +
            "Bass Boost: ${s(global.bassOk)}\n" +
            "Equalizer (low bands): ${s(global.eqOk)}\n" +
            "Loudness: ${s(global.loudOk)}\n" +
            "Apps being boosted individually: ${sessions.size}"
        prefs.edit().putString("status", txt).apply()
    }

    private fun startAsForeground() {
        val channelId = "bass_boost"
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(channelId, "Bass Boost", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val nb = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId)
        else Notification.Builder(this)
        val n = nb.setContentTitle("Bass Boost TV")
            .setContentText("Bass boost is always on")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(1, n)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(watchdog)
        try { unregisterReceiver(sessionReceiver) } catch (_: Exception) {}
        global.release()
        for (c in sessions.values) c.release()
        sessions.clear()
        super.onDestroy()
    }
}
